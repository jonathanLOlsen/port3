import React, { useEffect, useState } from "react";
import axios from "axios";
import { API_BASE_URL } from "../config/Config";
import { TMDB_API_KEY } from "../config/Config";
import PeopleCard from "../components/PeopleCard";
import { Link } from "react-router-dom";


const TMDB_BASE_URL = "https://api.themoviedb.org/3";

const People = () => {
    const [people, setPeople] = useState([]);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchPeople = async () => {
            try {
                // Fetch data from your own API
                const response = await axios.get(`${API_BASE_URL}/NameBasics/limited`, {
                    params: { limit: 10, pageNumber: 1 },
                });

                const peopleData = response.data.items;

                // Enhance data with TMDB profile images
                const updatedPeople = await Promise.all(
                    peopleData.map(async (person) => {
                        try {
                            // Fetch profile image from TMDB
                            const tmdbResponse = await axios.get(`${TMDB_BASE_URL}/search/person`, {
                                params: {
                                    api_key: TMDB_API_KEY,
                                    query: person.primaryName,
                                },
                            });

                            const tmdbPerson = tmdbResponse.data.results[0]; // Take the first result
                            if (tmdbPerson && tmdbPerson.profile_path) {
                                return {
                                    ...person,
                                    photo: `https://image.tmdb.org/t/p/w200${tmdbPerson.profile_path}`,
                                };
                            }
                        } catch (tmdbError) {
                            console.error(`Failed to fetch TMDB data for ${person.primaryName}:`, tmdbError);
                        }

                        // Fallback to original data if no TMDB data is available
                        return person;
                    })
                );

                setPeople(updatedPeople);
            } catch (err) {
                console.error("Failed to fetch people:", err);
                setError("Failed to load people.");
            }
        };

        fetchPeople();
    }, []);

    return (
        <div>
            <h1>Top Actors</h1>
            <p>Welcome to the People page, search and browse your favorite actors and movie crew members here.</p>
            {error && <p style={{ color: "red" }}>{error}</p>}
            <div style={{ display: "flex", flexWrap: "wrap", gap: "20px" }}>
                {people.map((person) => (
                    <Link
                        to={`${person.nConst}`}
                        style={{ textDecoration: "none", color: "inherit" }}
                        key={person.nConst}
                    >
                        <PeopleCard
                            name={person.primaryName}
                            imageUrl={person.photo} // Updated to include the fetched TMDB image
                            birth={person.birthYear}
                        />
                    </Link>
                ))}
            </div>
        </div>
    );
};

export default People;
