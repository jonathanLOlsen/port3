// src/config/Config.js
export const API_BASE_URL = "http://localhost:7247/api"; // main API base URL
export const TMDB_API_KEY = "91c1a80727c7e83025fadd1c0638eae1"; // TMDB API key
export const TMDB_BASE_URL = "https://api.themoviedb.org/3"; // TMDB base URL
